/* eslint-disable */
export default {
    "entrypoint": "./index.html",
    "appIcon": "./SafetyChat_AppIcon.png",
    "appId": "b31f19d9-d5d4-4400-a438-16387ff85ea3",
    "appName": "SDL Chat",
    "category": "WEB_VIEW",
    "additionalCategories": [],
    "locales": {
        "de_DE": {
            "appName": "SDL Chat",
            "appIcon": "./SafetyChat_AppIcon.png"
        }
    },
    "appVersion": "1.0.0",
    "minRpcVersion": "7.0.0",
    "minProtocolVersion": "5.0.0"
};
